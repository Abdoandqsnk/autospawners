package net.example.autospawners.mixin;

import net.example.autospawners.HudTextCollector;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Records every piece of text the HUD draws. The Component overload of text(...) is expected to
 * delegate to the FormattedCharSequence one, so these two cover everything.
 */
@Mixin(GuiGraphicsExtractor.class)
public class GuiGraphicsExtractorMixin {

    @Inject(method = "text(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V", at = @At("HEAD"))
    private void autospawners$string(Font font, String text, int x, int y, int color,
                                     boolean shadow, CallbackInfo ci) {
        HudTextCollector.add(text, false, x, y);
    }

    @Inject(method = "text(Lnet/minecraft/client/gui/Font;Lnet/minecraft/util/FormattedCharSequence;IIIZ)V",
            at = @At("HEAD"))
    private void autospawners$sequence(Font font, FormattedCharSequence text, int x, int y, int color,
                                       boolean shadow, CallbackInfo ci) {
        StringBuilder sb = new StringBuilder();
        boolean[] strike = {false};
        text.accept((index, style, codePoint) -> {
            sb.appendCodePoint(codePoint);
            if (style.isStrikethrough()) strike[0] = true;
            return true;
        });
        HudTextCollector.add(sb.toString(), strike[0], x, y);
    }
}
