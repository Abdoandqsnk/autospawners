package net.example.autospawners;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AutoSpawnersMod implements ClientModInitializer {

    private enum State { OFF, SEARCHING, GOING }

    // Matches "x, y, z" or "x y z" (negative numbers allowed). "(113,2m)" will not match.
    private static final Pattern XYZ =
            Pattern.compile("(-?\\d+)\\s*[, ]\\s*(-?\\d+)\\s*[, ]\\s*(-?\\d+)");

    private static State state = State.OFF;
    private static final Deque<BlockPos> queue = new ArrayDeque<>();
    private static final Set<BlockPos> done = new HashSet<>();
    private static BlockPos target;
    private static int ticks;
    private static float flightYaw;

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("autospawners")
                .executes(ctx -> { start(Minecraft.getInstance()); return 1; })
                .then(ClientCommandManager.literal("stop").executes(ctx -> {
                    stop(Minecraft.getInstance(), "Stopped.");
                    return 1;
                }))
                .then(ClientCommandManager.literal("reset").executes(ctx -> {
                    done.clear();
                    msg(Minecraft.getInstance(), "Cleared list of finished spawners.");
                    return 1;
                }))));

        ClientTickEvents.END_CLIENT_TICK.register(AutoSpawnersMod::tick);
    }

    // ---------------------------------------------------------------- control

    private static void start(Minecraft mc) {
        if (mc.player == null) return;
        queue.clear();
        target = null;
        flightYaw = mc.player.getYRot();
        state = State.SEARCHING;
        msg(mc, "Started. Looking for coordinates...");
    }

    private static void stop(Minecraft mc, String why) {
        state = State.OFF;
        queue.clear();
        target = null;
        mc.options.keyJump.setDown(false);
        if (mc.player != null) {
            mc.player.connection.sendChat("#stop");
            msg(mc, why);
        }
    }

    private static void msg(Minecraft mc, String s) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[AutoSpawners] " + s), false);
    }

    private static void startNext(Minecraft mc) {
        target = queue.poll();
        if (target == null) return;
        state = State.GOING;
        mc.options.keyJump.setDown(false);
        mc.player.connection.sendChat("#goto " + target.getX() + " " + target.getY() + " " + target.getZ());
        msg(mc, "Going to " + target.toShortString() + " (" + queue.size() + " more queued)");
    }

    /** A spawner is finished: remember it and move on to the next one (or back to searching). */
    private static void markDone(Minecraft mc, BlockPos p) {
        done.add(p);
        queue.remove(p);
        if (!p.equals(target)) return;

        msg(mc, "Spawner at " + p.toShortString() + " mined.");
        target = null;
        if (!queue.isEmpty()) {
            startNext(mc);
        } else {
            msg(mc, "Queue empty, looking for new coordinates...");
            state = State.SEARCHING;
            flightYaw = mc.player.getYRot();
        }
    }

    // ------------------------------------------------------------------- tick

    private static void tick(Minecraft mc) {
        if (state == State.OFF) return;
        if (mc.player == null || mc.level == null) { state = State.OFF; return; }
        ticks++;

        if (state == State.SEARCHING) {
            if (ticks % 20 == 0) {
                scanHud(mc);
                if (!queue.isEmpty()) { startNext(mc); return; }
            }
            elytraTick(mc);
        } else if (state == State.GOING && ticks % 10 == 0) {
            scanHud(mc);          // picks up new coordinates and "[X]" marks
            checkMinedBlock(mc);  // fallback: block itself is gone
        }
    }

    /** Fallback check: the spawner block is gone while we are close enough for the chunk to be loaded. */
    private static void checkMinedBlock(Minecraft mc) {
        if (state != State.GOING || target == null) return;
        if (mc.player.distanceToSqr(Vec3.atCenterOf(target)) > 12 * 12) return;
        if (mc.level.getBlockState(target).is(Blocks.SPAWNER)) return;
        markDone(mc, target);
    }

    // -------------------------------------------------- reading the corner

    /**
     * Reads the text the HUD drew in the top-left corner. Lines marked [X] or struck through are
     * finished spawners; every other line with an x, y, z triple is a spawner still to visit.
     */
    private static void scanHud(Minecraft mc) {
        if (mc.screen != null) return;
        for (HudTextCollector.Line line : HudTextCollector.snapshot()) {
            Matcher m = XYZ.matcher(line.text());
            while (m.find()) {
                BlockPos p = new BlockPos(Integer.parseInt(m.group(1)),
                                          Integer.parseInt(m.group(2)),
                                          Integer.parseInt(m.group(3)));
                if (line.mined()) {
                    markDone(mc, p);
                } else if (!done.contains(p) && !queue.contains(p) && !p.equals(target)) {
                    queue.add(p);
                }
            }
        }
    }

    // ----------------------------------------------------------------- elytra

    private static void elytraTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (!p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)) {
            stop(mc, "No elytra equipped, stopping.");
            return;
        }

        if (p.isFallFlying()) {
            mc.options.keyJump.setDown(false);
            p.setYRot(flightYaw);
            double y = p.getY();
            p.setXRot(y < 110 ? -35f : (y > 200 ? 15f : -5f)); // keep altitude in a sane band
            if (p.getDeltaMovement().length() < 1.0 && ticks % 10 == 0) useFirework(mc);
        } else {
            // Take off: jump, then tap jump again in the air to open the elytra (vanilla does the rest).
            mc.options.keyJump.setDown(ticks % 2 == 0);
        }
    }

    private static void useFirework(Minecraft mc) {
        LocalPlayer p = mc.player;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(Items.FIREWORK_ROCKET)) {
                p.getInventory().setSelectedSlot(i);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                return;
            }
        }
        stop(mc, "Out of fireworks in the hotbar, stopping.");
    }
}
