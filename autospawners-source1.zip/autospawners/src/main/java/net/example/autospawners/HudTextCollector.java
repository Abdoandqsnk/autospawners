package net.example.autospawners;

import net.minecraft.client.Minecraft;

import java.util.*;

/** Remembers text drawn in the top-left quarter of the in-game screen during the last half second. */
public final class HudTextCollector {

    public record Line(String text, boolean mined) {}

    private record Entry(String text, boolean strike, int y, long time) {}

    private static final long MAX_AGE_MS = 500;
    private static final Map<String, Entry> entries = new HashMap<>();

    private HudTextCollector() {}

    public static synchronized void add(String text, boolean strike, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.screen != null || text == null || text.isBlank()) return;
        if (x > mc.getWindow().getGuiScaledWidth() / 2 || y > mc.getWindow().getGuiScaledHeight() / 2) return;
        if (text.contains("\u00a7m")) strike = true; // legacy strikethrough code
        entries.put(y + "|" + x, new Entry(text, strike, y, System.currentTimeMillis()));
    }

    public static synchronized List<Line> snapshot() {
        long now = System.currentTimeMillis();
        entries.values().removeIf(e -> now - e.time() > MAX_AGE_MS);
        List<Entry> sorted = new ArrayList<>(entries.values());
        sorted.sort(Comparator.comparingInt(Entry::y));
        List<Line> out = new ArrayList<>();
        for (Entry e : sorted) {
            out.add(new Line(e.text(), e.strike() || e.text().contains("[X]")));
        }
        return out;
    }
}
