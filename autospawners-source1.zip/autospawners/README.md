# AutoSpawners (Fabric, Minecraft 26.2, client-side)

Commands:
  /autospawners         start
  /autospawners stop    stop (also sends #stop)
  /autospawners reset   forget already-mined spawners

How it reads coordinates:
  A mixin on GuiGraphicsExtractor records text drawn in the top-left quarter of the screen
  (SpawnerFinder's list). Lines with "x, y, z" are targets; "[X]" or strikethrough = already mined.

Build (Java 25 + Gradle 9.5.1), either:
  A) Upload this folder to a GitHub repo -> Actions tab -> "build" -> download artifact "autospawners-jar".
  B) Locally: copy src/ and the gradle files onto the Fabric 26.2 template from fabricmc.net/develop
     (it contains gradlew), then run:  gradlew build   -> build/libs/autospawners-1.0.0.jar

Install: put autospawners-1.0.0.jar (NOT the -sources jar) in your mods folder.
Elytra mode: wear an elytra and keep fireworks in your hotbar.
